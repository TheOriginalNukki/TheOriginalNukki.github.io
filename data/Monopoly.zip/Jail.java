package main;

/* Author: Serge Shpolskyy
 * Date: Jan 12, 2023
 * Description: Jail class has some questions for players to answer, if they answer it, they continue, if not,
 * stay in jail for one more turn
 */

import java.util.*;

public class Jail {

	//variables
	Scanner input = new Scanner(System.in);
	private int checkAns;
	
	//Constructor
	public Jail() {
		
		checkAns = 1;
	}
	
	//Pre: Null
	//Post: void
	//Action: Returns a question that player has to answer. If he doesn't he stays for one more turn.
	public void PrisonQuiz(int a) {
		
		System.out.println("\n\nWelcome to hell! Be ready to answer questions, or else you'll be stuck here for a long time!\n");
		
		if(a == 1) {
			
			System.out.println("What toxic material can computers, monitors and other peripheral devices contain?");
			System.out.println("1) Uranium and Cadmium\n2) Lead and Mercury\n3) Beryllium");
			int wans = input.nextInt();
			
			if(wans == 2) {
				
				System.out.println("This is correct! You get to continue playing the game in the next move.\n");
				checkAns++;
				
			} else {
				
				System.out.println("Incorect answer, im sorry :(\nYou will have to stay here for little longer.\n");
				checkAns = 0;
			}
			
		} else if(a == 2) {
			
			System.out.println("How can you avoid wasting electricity?");
			System.out.println("1) Turn off your computer or monitor when not in use\n2) Use laptop or tablet instead of desktop\n3) Buy LED lamps instead of other ones");
			int wans = input.nextInt();
			
			if(wans == 1 || wans == 2 || wans == 3) {
				
				System.out.println("This is correct! You get to continue playing the game in the next move.\n");
				checkAns++;
				
			} else {
				
				System.out.println("Bruh, you literally had to choose one of the options to proceed, they are all correct :|\nGuess you are staying here for a little longer, LOL.\n");
				checkAns = 0;
			}
			
		} else if(a == 3) {
			
			System.out.println("Is avoiding wasting paper going to reduce impacton the environment?");
			System.out.println("1) Yes\n2) No\n3) Stop bothering me, I like it here");
			int wans = input.nextInt();
			
			if(wans == 1) {
				
				System.out.println("This is correct! You get to continue playing the game in the next move.\n");
				checkAns++;
				
			} else {
				
				System.out.println("The answer you have given was not correct, sorry :(\nGuess you have to stay here a little longer\n");
				checkAns = 0;
			}
			
		} else if(a == 4) {
			
			System.out.println("What do you think of cloud storage?");
			System.out.println("1) I absolutely love, you should use it everytime you get a chance\n2) Well, you can use it sometimes I guess\n3) No, this is very bad for our environment, you should try to store everything on your devices.");
			int wans = input.nextInt();
			
			if(wans == 3) {
				
				System.out.println("This is correct! You get to continue playing the game in the next move.\n");
				checkAns++;
				
			} else {
				
				System.out.println("NO! You want to try to store your data on your devices,\nbecause when you save something to the cloud, it gets saved on the server,\nwhich has to be powered by a lot of electricity.\n");
				checkAns = 0;
			}
			
		} else if(a == 5) {
			
			System.out.println("Congrats! You don't really have to answer a quuestion!!\nYou just have to read this message to strengthen your awarness of impact on the environment\nYou will be able to continue playing the game in the next move :)");
			System.out.println("You should be awarem that emails use a lot of space on the servers,\nso you want to stick to this tips while writing your email:");
			System.out.println("Send fewer emails and limit the number of recipients;\n"
					+ "- Write emails in text format rather than HTML (12 times less heavy and therefore less energy consuming);\n"
					+ "- Avoid attachments and email signatures, especially images that weigh down mailings;\n"
					+ "- Unsubscribe from the newsletters you’re no longer reading;\n"
					+ "- Do not print your emails.\n");
			checkAns++;
			
		}
	}
	
	//Pre: Null
	//Post: integer
	//Action: return check value which says whether player can leave the jail or not.
	public int check() {
		
		return checkAns;
	}
	
}
