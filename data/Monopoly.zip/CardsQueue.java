package main;

/* Author: Serge Shpolskyy
 * Date: Jan 13, 2023
 * Description: Queue that stores values of the cards.
 */

public class CardsQueue{
	
	//variables
	private int front, back, capacity; 
    private int[] data; //stores card values, not the whole cards.
   
    //Constructor
    public CardsQueue(int size) { 
    	
        front = 0;
        back = 0;
        capacity = size; 
        data = new int[capacity]; 
    } 
   
	//Pre: Null
	//Post: void
	//Action: adds new integer to the queue.
    public void enqueue(int item)  { 
    	
        if (capacity == back) { 
        	
            System.out.printf("Queue is full\n"); 
        } 
   
        else { 
        	
            data[back] = item; 
            back++; 
        }  
    } 
   
	//Pre: Null
	//Post: void
	//Action: removes integer from the queue.
    public void dequeue()  { 

        if (front == back) { 
        	
            System.out.printf("Queue is empty"); 
            
        } else { 
        	
            for (int i = 0; i < back - 1; i++) { 
            	
                data[i] = data[i + 1]; 
            } 
   
            if (back < capacity) {
            	
                data[back] = 0; 
            }
            back--;             
        } 
    } 
    
	//Pre: Null
	//Post: boolean
	//Action: checks whether the queue is empty.
    public boolean isEmpty() {
    	
    	return front == back;
    }
    
	//Pre: Null
	//Post: boolean
	//Action: checks whether the queue is full.
    public boolean isFull() {
    	
    	return capacity == back;
    }
   
	//Pre: Null
	//Post: String
	//Action: prints the whole queue
    public String toString() {
    	
    	String info = "Queue:\n";
		
		for(int i = 0; i < data.length; i++) {
			
			info += data[i] + "\n";
		}
		
		return info; 
    } 
   
	//Pre: Null
	//Post: integer
	//Action: returns integer from the front.
    public int front() {
    	
        return data[front];
    } 
} 
