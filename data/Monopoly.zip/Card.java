package main;

/* Author: Serge Shpolskyy
 * Date: Jan 14, 2023
 * Description: abstract parent class for cards that are going to be pulled out
 * during the game.
 */


public abstract class Card {

	//variables
	protected int value;
	protected Player player;
	
	//Constructor
	public Card(int a, Player b) {
		
		value = a;
		player = b;
	}
	
	//Pre: Null
	//Post: void
	//Action: Assigns what card are you pulling up related to the value.
	public abstract void wCard(); 
		
}
