package main;

/* Author; Serge Shpolskyy
 * Date: Jan 14, 2023
 * Description: Stores some of the Chance cards in it. Assigns certain card due to the value which was taken
 * from the CardsQueue class.
 */

public class Chance extends Card{

	//Constructor
	public Chance(int a, Player b) {
		
		super(a, b);
	}
	
	//Pre: Null
	//Post: void
	//Action: assigns a certain value to the card, and then shows it to the user.
	public void wCard() {
		
		if(value == 1) {
			
			System.out.println("\nGet $200\n");
			player.setMoney(player.getMoney() + 200);
			
		} else if(value == 2) {
			
			System.out.println("\nGet $500\n");
			player.setMoney(player.getMoney() + 500);
			
		} else if(value == 3) {
			
			System.out.println("\nA robber demands to give him $100. You better do so.\n");
			player.setMoney(player.getMoney()-100);
			
		} else if(value == 4) {
			
			System.out.println("\nNothing heppened. Unfortunately\n");
			
		} else if(value == 5) {
			
			System.out.println("\nYou have decided to donate some ($200) of your money to charity.\nWhat a generous move!\n");
			player.setMoney(player.getMoney() - 200);
		}
	}
	
}
