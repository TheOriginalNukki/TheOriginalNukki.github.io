package main;

/* Author: Serge Shpolskyy
 * Date: Jan 21, 2023
 * Description: The class stores all of the values Player has: his properties, money, name,
 * whether he can buy houses on his properties, whether he owns the property and his position on the board.
 */

import java.text.NumberFormat;

public class Player {

	//variables
	NumberFormat decimal = NumberFormat.getCurrencyInstance();
	private String name;
	private int money;
	private Property[] properties;
	private int position;
	private int yellowPoints;
	private int bluePoints;
	private int redPoints;
	private int greenPoints;
	private int whitePoints;
	private int IBM;
	private int Razer;
	private int ManageEngine;
	private int Amazon;
	private int Ericsson;
	private int Belking;
	private int Honeywell;
	private int Apple;
	private int Samsung;
	private int Dell;
	private int HP;
	private int Staples;
	private int Intel;
	
	//Constructor
	public Player(String aname) {
		
		name = aname;
		money = 1500;
		properties = new Property[0];
		position = 1;
		yellowPoints = 0;
		bluePoints = 0;
		redPoints = 0;
		greenPoints = 0;
		whitePoints = 0;
		IBM = 0;
		Razer = 0;
		ManageEngine = 0;
		Amazon = 0;
		Ericsson = 0;
		Belking = 0;
		Honeywell = 0;
		Apple = 0;
		Samsung = 0;
		Dell = 0;
		HP = 0;
		Staples = 0;
		Intel = 0;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns money.
	public int getMoney() {
		
		return money;
	}
	
	//Pre: Null
	//Post: void
	//Action: sets money.
	public void setMoney(int a) {
		
		money = a;
	}
	
	//Pre: Null
	//Post: void
	//Action: sets position.
	public void setPosition(int a) {
		
		position = a;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns position.
	public int getPosition() {
		
		return position;
	}
	
	//Pre: Null
	//Post: String
	//Action: returns name.
	public String getName() {
		
		return name;
	}
	
	//Pre: Null
	//Post: Property[]
	//Action: returns properties array.
	public Property[] getProperties() {
		
		return properties;
	}
	
	//Pre: Null
	//Post: integer[]
	//Action: returns properties' prices array.
	public int[] getPropertiesPrices() {
		
		int[] a = new int[properties.length];
		
		for(int i = 0; i < a.length; i++) {
			
			a[i] = properties[i].getPrice();
		}
		
		return a;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds yellow point to check whether the player can buy houses on properties of this color.
	public void addYellowPoints() {
		
		yellowPoints++;
	}
	
	//Pre: Null
	//Post: boolean
	//Action: checks whether player can buy houses on yellow-colored properties.
	public boolean checkYellowHouse() {
		
		return yellowPoints == 3;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds blue point to check whether the player can buy houses on properties of this color.
	public void addBluePoints() {
		
		bluePoints++;
	}
	
	//Pre: Null
	//Post: boolean
	//Action: checks whether player can buy houses on blue-colored properties.
	public boolean checkBlueHouse() {
		
		return bluePoints == 2;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds red point to check whether the player can buy houses on properties of this color.
	public void addRedPoints() {
		
		redPoints++;
	}
	
	//Pre: Null
	//Post: boolean
	//Action: checks whether player can buy houses on red-colored properties.
	public boolean checkRedHouse() {
		
		return redPoints == 2;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds green point to check whether the player can buy houses on properties of this color.
	public void addGreenPoints() {
		
		greenPoints++;
	}
	
	//Pre: Null
	//Post: boolean
	//Action: checks whether player can buy houses on green-colored properties.
	public boolean checkGreenHouse() {
		
		return greenPoints == 3;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds white point to check whether the player can buy houses on properties of this color.
	public void addWhitePoints() {
		
		whitePoints++;
	}
	
	//Pre: Null
	//Post: boolean
	//Action: checks whether player can buy houses on white-colored properties.
	public boolean checkWhiteHouse() {
		
		return whitePoints == 3;
	}
	
	//Pre: Null
	//Post: double
	//Action: returns player's money in euros.
	public double convertToEuros(int a) {
		
		if(a == 1){
			
			return 0.69;
			
		} else {
			
			return 0.69 + convertToEuros(a-1);
			
		}
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns player's money in hryvnas (Ukrainian currency).
	public int convertToHryvnas(int a) {
		
		if(a == 1){
			
			return 27;
			
		} else {
			
			return 27 + convertToHryvnas(a-1);
			
		}
	}
	
	//Pre: Null
	//Post: double
	//Action: returns player's money in US Dollars.
	public double convertToUSDollars(int a) {
		
		if(a == 1) {
			
			return 0.75;
			
		} else {
			
			return 0.75 + convertToUSDollars(a-1);
		}
	}
	
	//Pre: Null
	//Post: void
	//Action: adds points for IBM, if you own this property.
	//Used to check whether you are the owner to prevent paying money to the opposite player.
	public void addIBM() {
		
		IBM = 1;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns IBM points.
	public int checkIBM() {
		
		return IBM;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds points for Razer, if you own this property.
	//Used to check whether you are the owner to prevent paying money to the opposite player.
	public void addRazer() {
		
		Razer = 1;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns Razer points.
	public int checkRazer() {
		
		return Razer;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds points for ManageEngine, if you own this property.
	//Used to check whether you are the owner to prevent paying money to the opposite player.
	public void addManageEngine() {
		
		ManageEngine = 1;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns ManageEngine points.
	public int checkManageEngine() {
		
		return ManageEngine;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds points for Amazon, if you own this property.
	//Used to check whether you are the owner to prevent paying money to the opposite player.
	public void addAmazon() {
		
		Amazon = 1;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns Amazon points.
	public int checkAmazon() {
		
		return Amazon;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds points for Ericsson, if you own this property.
	//Used to check whether you are the owner to prevent paying money to the opposite player.
	public void addEricsson() {
		
		Ericsson = 1;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns Ericsson points.
	public int checkEricsson() {
		
		return Ericsson;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds points for Belking, if you own this property.
	//Used to check whether you are the owner to prevent paying money to the opposite player.
	public void addBelking() {
		
		Belking = 1;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns Belking points.
	public int checkBelking() {
		
		return Belking;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds points for Honeywell, if you own this property.
	//Used to check whether you are the owner to prevent paying money to the opposite player.
	public void addHoneywell() {
		
		Honeywell = 1;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns Honeywell points.
	public int checkHoneywell() {
		
		return Honeywell;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds points for Apple, if you own this property.
	//Used to check whether you are the owner to prevent paying money to the opposite player.
	public void addApple() {
		
		Apple = 1;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns Apple points.
	public int checkApple() {
		
		return Apple;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds points for Samsung, if you own this property.
	//Used to check whether you are the owner to prevent paying money to the opposite player.
	public void addSamsung() {
		
		Samsung = 1;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns Samsung points.
	public int checkSamsung() {
		
		return Samsung;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds points for Dell, if you own this property.
	//Used to check whether you are the owner to prevent paying money to the opposite player.
	public void addDell() {
		
		Dell = 1;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns Dell points.
	public int checkDell() {
		
		return Dell;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds points for HP, if you own this property.
	//Used to check whether you are the owner to prevent paying money to the opposite player.
	public void addHP() {
		
		HP = 1;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns HP points.
	public int checkHP() {
		
		return HP;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds points for Staples, if you own this property.
	//Used to check whether you are the owner to prevent paying money to the opposite player.
	public void addStaples() {
		
		Staples = 1;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns Staples points.
	public int checkStaples() {
		
		return Staples;
	}
	
	//Pre: Null
	//Post: void
	//Action: adds points for Intel, if you own this property.
	//Used to check whether you are the owner to prevent paying money to the opposite player.
	public void addIntel() {
		
		Intel = 1;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns Intel points.
	public int checkIntel() {
		
		return Intel;
	}

	public Property[] addProperty(Property a) {
	
		 Property[] newarr = new Property[properties.length + 1];
	
	     for(int i = 0; i < properties.length; i++) {
	
	         newarr[i] = properties[i];
	     }
	     newarr[properties.length] = a;
	
	     return properties = newarr;
	
	}	
	
	//Pre: Null
	//Post: String
	//Action: Prints all player's data.
	public String toString() {
		
		String info = "Name: " + name + "\nMoney: " + decimal.format(money) + "\nProperties:\n";
		
		if(properties.length == 0) {
			
			info += " None";
			
		} else {
			
			info += "\n";
			for(int i = 0; i < properties.length; i++) {
				
				info += (i+1) + ")\n" + properties[i].toString() + "\n\n";
			}
		}
		
		info += "\n";
		
		return info;
	}
	
	//Pre: Null
	//Post: String
	//Action: Prints all player's data, but more in a raw way for file savings.
	public String saveData() {
		
		String info = name + "\n" + money + "\n";
		
		if(properties.length == 0) {
			
			System.out.println("");
			
		} else {
			
			for(int i = 0; i < properties.length; i++) {
				
				info += properties[i].saveData() + "\n";
			}
		}
		
		return info;
	}
}
