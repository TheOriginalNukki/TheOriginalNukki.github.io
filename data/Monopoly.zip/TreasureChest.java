package main;

/* Author; Serge Shpolskyy
 * Date: Jan 14, 2023
 * Description: Stores some of the Treasure Chest cards in it. Assigns certain card due to the value which was taken
 * from the CardsQueue class.
 */

public class TreasureChest extends Card{

	//Constructor
	public TreasureChest(int a, Player b) {
		
		super(a, b);
	}
	
	//Pre: Null
	//Post: void
	//Action: assigns a certain value to the card, and then shows it to the user.
	public void wCard() {
		
		if(value == 1) {
			
			System.out.println("\nEarn $100\n");
			player.setMoney(player.getMoney() + 100);
			
		} else if(value == 2) {
			
			System.out.println("\nBank error in your favour. Collect $200\n");
			player.setMoney(player.getMoney() + 200);
			
		} else if(value == 3) {
			
			System.out.println("\nIncome tax refund. Collect $20\n");
			player.setMoney(player.getMoney() + 20);
			
		} else if(value == 4) {
			
			System.out.println("\nYou won a JACKPOT! Recieve $1000\n");
			player.setMoney(player.getMoney() + 1000);
			
		} else if(value == 5) {
			
			System.out.println("\nEmpty Card.\n");
		}
	}
}
