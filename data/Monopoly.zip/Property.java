package main;

/* Author: Serge Shpolskyy
 * Date: Jan 21, 2023
 * Description: Property class that stores all of the value property has.
 * Price, rent, color, etc.
 */

import java.text.NumberFormat;

public class Property {

	//variables
	NumberFormat decimal = NumberFormat.getCurrencyInstance();
	private int price;
	private int rent; // would increase after buying houses
	private String name;
	private int availability;
	private String color;
	
	//Constructor
	public Property(int price, int brent, String cname, String dcolor) {
		
		this.price = price;
		rent = brent;
		name = cname;
		availability = 1;
		color = dcolor;
	}
	//Pre: Null
	//Post: integer
	//Action: returns the price of the property.
	public int getPrice() {
		
		return price;
	}
	
	//Pre: Null
	//Post: String
	//Action: returns the name of the property.
	public String getName() {
		
		return name;
	}
	
	//Pre: Null
	//Post: String
	//Action: returns the color of the property.
	public String getColor( ) {
	
		return color;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns availability.
	public int getAvailability() {
		
		return availability;
	}
	
	//Pre: Null
	//Post: void
	//Action: sets availability, value which tells us whether the property is already bought or not.
	public void setAvailability(int a) {
		
		availability = a;
	}
	
	//Pre: Null
	//Post: integer
	//Action: returns rent.
	public int getRent() {
		
		return rent;
	}
	
	//Pre: Null
	//Post: void
	//Action: sets rent of the property. Increases if houses are bought.
	public void setRent(int a) {
		
		rent = a;
	}
	
	//Pre: Null
	//Post: String
	//Action: prints all of the property's data.
	public String toString() {
		
		String info = "Name: " + name + "\nPrice: " + decimal.format(price) + "\nRent: " + decimal.format(rent) + "\nColor: " + color;
		
		return info;
	}
	
	//Pre: Null
	//Post: String
	//Action: prints all of the property's data, but more in a raw way for file savings.
	public String saveData() {
		
		String info = name + "\n" + price + "\n" + rent + "\n" + color + "\n" + availability;
		return info;
	}
}
