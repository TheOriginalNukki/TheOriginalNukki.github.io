package main;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[][] a = {{"hello", "a", "b"}, {"g", "hh", "t"}};
		
		for(int i = 0; i < a.length; i++) {
			for(int j = 0; j < a[i].length; j++) {
				
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
	}

}
