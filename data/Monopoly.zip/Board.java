package main;

/* Author: Serge Shpolskyy
 * Date: Jan 21, 2023
 * Description: The class stores all of the properties that are used in the game.
 * Properties are stored in one class so that all players will have access to same properties
 */

import java.util.*;

public class Board {

	//variables
	Random number = new Random();
	private int rent;
	private Property IBM;
	private Property Razer;
	private Property ManageEngine;
	private Property Amazon;
	private Property Ericsson;
	private Property Belking;
	private Property Honeywell;
	private Property Apple;
	private Property Samsung;
	private Property Dell;
	private Property HP;
	private Property Staples;
	private Property Intel;
	private Jail prison;
	
	//Constructor
	public Board() {
		
		rent = 0;
		IBM = new Property(700, 450, "IBM", "white");
		Razer = new Property(500, 400, "Razer", "green");
		ManageEngine = new Property(300, 200, "ManageEngine", "red");
		Amazon = new Property(450, 250, "Amazon", "white");
		Ericsson = new Property(100, 50, "Ericsson", "white");
		Belking = new Property(300, 150, "Belking", "yellow");
		Honeywell = new Property(400, 300, "Honeywell", "yellow");
		Apple = new Property(800, 800, "Apple", "blue");
		Samsung = new Property(850, 1050, "Samsung", "blue");
		Dell = new Property(300, 200, "Dell", "yellow");
		HP = new Property(200, 70, "HP", "red");
		Staples = new Property(300, 200, "Staples", "green");
		Intel = new Property(200, 100, "Intel", "green");
		prison = new Jail();
	}
	
	//Pre: Null
	//Post: Void
	//Action: Adds money to rent if player stepped on someone's property.
	public void payRent(int a) {
		
		rent += a;
	}
	
	//Pre: Null
	//Post: Integer
	//Action: Returns rent.
	public int getRent() {
		
		return rent;
	}
	
	//Pre: Null
	//Post: Jail
	//Action: returns prison.
	public Jail getPrison() {
		
		return prison;
	}
	
	//Pre: Null
	//Post: Property
	//Action: returns IBM.
	public Property toIBM() {
		
		return IBM;
	}
	
	//Pre: Null
	//Post: Void
	//Action: Used to set Property if loading the game from file. Sets IBM.
	public void setIBM(Property a) {
		
		IBM = a;
	}
	
	//Pre: Null
	//Post: Property
	//Action: returns Razer.
	public Property toRazer() {
		
		return Razer;
	}
	
	//Pre: Null
	//Post: Void
	//Action: Used to set Property if loading the game from file. Sets Razer.	
	public void setRazer(Property a) {
		
		Razer = a;
	}
	
	//Pre: Null
	//Post: Property
	//Action: returns ManageEngine.
	public Property toManageEngine() {
		
		return ManageEngine;
	}
	
	//Pre: Null
	//Post: Void
	//Action: Used to set Property if loading the game from file. Sets ManageEngine.
	public void setManageEngine(Property a) {
		
		ManageEngine = a;
	}
	
	//Pre: Null
	//Post: Property
	//Action: returns Amazon.
	public Property toAmazon() {
		
		return Amazon;
	}
	
	//Pre: Null
	//Post: Void
	//Action: Used to set Property if loading the game from file. Sets Amazon.
	public void setAmazon(Property a) {
		
		Amazon = a;
	}
	
	//Pre: Null
	//Post: Property
	//Action: returns Ericsson.
	public Property toEricsson() {
		
		return Ericsson;
	}
	
	//Pre: Null
	//Post: Void
	//Action: Used to set Property if loading the game from file. Sets Ericsson.
	public void setEricsson(Property a) {
		
		Ericsson = a;
	}
	
	//Pre: Null
	//Post: Property
	//Action: returns Belking.
	public Property toBelking() {
		
		return Belking;
	}
	
	//Pre: Null
	//Post: Void
	//Action: Used to set Property if loading the game from file. Sets Belking.
	public void setBelking(Property a) {
		
		Belking = a;
	}
	
	//Pre: Null
	//Post: Property
	//Action: returns Honeywell.
	public Property toHoneywell() {
		
		return Honeywell;
	}
	
	//Pre: Null
	//Post: Void
	//Action: Used to set Property if loading the game from file. Sets Honeywell.
	public void setHoneywell(Property a) {
		
		Honeywell = a;
	}
	
	//Pre: Null
	//Post: Property
	//Action: returns Apple.
	public Property toApple() {
		
		return Apple;
	}
	
	//Pre: Null
	//Post: Void
	//Action: Used to set Property if loading the game from file. Sets Apple.
	public void setApple(Property a) {
		
		Apple = a;
	}
	
	//Pre: Null
	//Post: Property
	//Action: returns Samsung.
	public Property toSamsung() {
		
		return Samsung;
	}
	
	//Pre: Null
	//Post: Void
	//Action: Used to set Property if loading the game from file. Sets Samsung.
	public void setSamsung(Property a) {
		
		Samsung = a;
	}
	
	//Pre: Null
	//Post: Property
	//Action: returns Dell.
	public Property toDell() {
		
		return Dell;
	}
	
	//Pre: Null
	//Post: Void
	//Action: Used to set Property if loading the game from file. Sets Dell.
	public void setDell(Property a) {
		
		Dell = a;
	}
	
	//Pre: Null
	//Post: Property
	//Action: returns HP.
	public Property toHP() {
		
		return HP;
	}
	
	//Pre: Null
	//Post: Void
	//Action: Used to set Property if loading the game from file. Sets HP.
	public void setHP(Property a) {
		
		HP = a;
	}
	
	//Pre: Null
	//Post: Property
	//Action: returns Staples.
	public Property toStaples() {
		
		return Staples;
	}
	
	//Pre: Null
	//Post: Void
	//Action: Used to set Property if loading the game from file. Sets Staples.
	public void setStaples(Property a) {
		
		Staples = a;
	}
	
	//Pre: Null
	//Post: Property
	//Action: returns Intel.
	public Property toIntel() {
		
		return Intel;
	}
	
	//Pre: Null
	//Post: Void
	//Action: Used to set Property if loading the game from file. Sets Intel.
	public void setIntel(Property a) {
		
		Intel = a;
	}
}
