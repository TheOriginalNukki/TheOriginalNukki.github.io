package main;

/* Author: Serge Shposlkyy
 * Date: Jan 21, 2023
 * Description: This is the famous "monopoly " game. The rules are pretty much the same: you throw the dice,
 * you roll a number and end up at a certain position.
 * You can either end up at the property which you can buy, or if this property is already taken, you have to pay the rent.
 * You can also end up at the Chance and Treasure Chest cards positions. They can either take some money from you, or give it to you.
 * You can also end up at the free parking, where you don't have to do anything.
 * However, you don't want to end up at the jail, because then you will have to answer to one of the questions related to
 * the pollution of our environment. If you don't answer, you stay there for one more turn.
 * All of the properties are based on the companies that care about our environment.
 * Player wins when he earns more than $10000, or when other player is a bankrupt.
 * You have and option to start a new game, then save your balance and properties to the file, and load them in another game.
 * Good luck!
 */

import java.util.*;
import java.io.*;
import java.text.DecimalFormat;

public class ICS4U_FP {

	//Main class. Basically a constructor for all of the methods, this is where all of the magic starts working.
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		int choose1, choose2;
		
		System.out.println("Welcome to the\n");
		System.out.println("\n"
				+ "████████╗███████╗░█████╗░██╗░░██╗███╗░░██╗░█████╗░██████╗░░█████╗░██╗░░░░░██╗░░░██╗\n"
				+ "╚══██╔══╝██╔════╝██╔══██╗██║░░██║████╗░██║██╔══██╗██╔══██╗██╔══██╗██║░░░░░╚██╗░██╔╝\n"
				+ "░░░██║░░░█████╗░░██║░░╚═╝███████║██╔██╗██║██║░░██║██████╔╝██║░░██║██║░░░░░░╚████╔╝░\n"
				+ "░░░██║░░░██╔══╝░░██║░░██╗██╔══██║██║╚████║██║░░██║██╔═══╝░██║░░██║██║░░░░░░░╚██╔╝░░\n"
				+ "░░░██║░░░███████╗╚█████╔╝██║░░██║██║░╚███║╚█████╔╝██║░░░░░╚█████╔╝███████╗░░░██║░░░\n"
				+ "░░░╚═╝░░░╚══════╝░╚════╝░╚═╝░░╚═╝╚═╝░░╚══╝░╚════╝░╚═╝░░░░░░╚════╝░╚══════╝░░░╚═╝░░░");
		System.out.println("\n\nSelect one of the options below:");
		
		//do-while loop to avoid wrong inputs.
		do {
			
			System.out.println("1. Play the Game\n2. Read an instructions.");
			choose1 = input.nextInt();
			
			//If you have selected to play the game, you proceed to the next menu option, otherwise instructions pop up.
			if(choose1 == 1) {
				
				System.out.println("\n\nSelect one of the options below:");
				
				//do-while loop to avoid wrong inputs.
				do {
					
					System.out.println("1. Start new Game\n2. Continue from saved file.");
					choose2 = input.nextInt();
					System.out.println("");
					
					//if you start a new game
					if(choose2 == 1) {
						
						twoPlayersGame(input);
						
					//if you load the game from the file.
					} else if(choose2 == 2) {
						
						twoPlayersGameFile(input);
						
					} else {
						
						System.out.println("\nInvalid input, please try again.\n");
					}
					
				}while(choose2 < 1 || choose2 > 2);
				
			} else if(choose1 == 2) {
				
				System.out.println("\n\n"
						+ "██╗███╗░░██╗░██████╗████████╗██████╗░██╗░░░██╗░█████╗░████████╗██╗░█████╗░███╗░░██╗░██████╗\n"
						+ "██║████╗░██║██╔════╝╚══██╔══╝██╔══██╗██║░░░██║██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║██╔════╝\n"
						+ "██║██╔██╗██║╚█████╗░░░░██║░░░██████╔╝██║░░░██║██║░░╚═╝░░░██║░░░██║██║░░██║██╔██╗██║╚█████╗░\n"
						+ "██║██║╚████║░╚═══██╗░░░██║░░░██╔══██╗██║░░░██║██║░░██╗░░░██║░░░██║██║░░██║██║╚████║░╚═══██╗\n"
						+ "██║██║░╚███║██████╔╝░░░██║░░░██║░░██║╚██████╔╝╚█████╔╝░░░██║░░░██║╚█████╔╝██║░╚███║██████╔╝\n"
						+ "╚═╝╚═╝░░╚══╝╚═════╝░░░░╚═╝░░░╚═╝░░╚═╝░╚═════╝░░╚════╝░░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝╚═════╝░");
				
				System.out.println("\n\nWelcome to the Monopoly based game called Technopoly.\nThe rules are pretty much the same as the monopoly rules,\nso if you don't know how to play monopoly I would suggest you to read Monopoly rules.\nHowever there are some changes in this game, when you get to the prison,\nYou have to answer some environmentally relatead questions.\nAlso properties are based on companies that care about our environment.\nThe game is for 2 players, enjoy!\n\n");
				
			} else {
				
				System.out.println("\nInvalid input, please try again.\n");
			}
			
		}while(choose1 != 1);
	}
	
	//This is the method that corresponds to the new two-player game.
	public static void twoPlayersGame(Scanner input) {
		
		Random number = new Random();
		CardsQueue cq = new CardsQueue(10);
		CardsQueue tq = new CardsQueue(10);
		String name1, name2;
		
		//adding random card values to the queue.
		for(int i = 0; i < 10; i++) {
			
			cq.enqueue(number.nextInt(5)+1);
			tq.enqueue(number.nextInt(5)+1);
		}
		
		System.out.println("Player number 1, please enter your name.");
		name1 = input.next();
		
		System.out.println("Player number 2, please enter your name.");
		name2 = input.next();
		System.out.println("\n\n"
				+ "██████╗░███████╗░██████╗░██╗███╗░░██╗██╗\n"
				+ "██╔══██╗██╔════╝██╔════╝░██║████╗░██║██║\n"
				+ "██████╦╝█████╗░░██║░░██╗░██║██╔██╗██║██║\n"
				+ "██╔══██╗██╔══╝░░██║░░╚██╗██║██║╚████║╚═╝\n"
				+ "██████╦╝███████╗╚██████╔╝██║██║░╚███║██╗\n"
				+ "╚═════╝░╚══════╝░╚═════╝░╚═╝╚═╝░░╚══╝╚═╝\n\n");
		
		Player a1 = new Player(name1);
		Player a2 = new Player(name2);
		
		Jail j1 = new Jail();
		Jail j2 = new Jail();
		
		Board board1 = new Board();
		
		//do-while loop until someone wins the game.
		do {
			
			playerTurn(board1, a1, input, number, cq, tq, j1);
			
			playerTurn(board1, a2, input, number, cq, tq, j2);
				
		}while(a1.getMoney() < 10000 && a2.getMoney() < 10000 && a1.getMoney() > 0 && a2.getMoney() > 0);
		
		//if-else statement prints different messages depending on who has won and how.
		if(a1.getMoney() >= 10000) {
			
			System.out.println("\n\n"
					+ "███████╗██╗███╗░░██╗██╗░██████╗██╗░░██╗██╗\n"
					+ "██╔════╝██║████╗░██║██║██╔════╝██║░░██║██║\n"
					+ "█████╗░░██║██╔██╗██║██║╚█████╗░███████║██║\n"
					+ "██╔══╝░░██║██║╚████║██║░╚═══██╗██╔══██║╚═╝\n"
					+ "██║░░░░░██║██║░╚███║██║██████╔╝██║░░██║██╗\n"
					+ "╚═╝░░░░░╚═╝╚═╝░░╚══╝╚═╝╚═════╝░╚═╝░░╚═╝╚═╝\n\n" + a1.getName() + " has earned more than \n\n"
							+ "░███████╗░░███╗░░░█████╗░██╗░█████╗░░█████╗░░█████╗░██╗██╗██╗\n"
							+ "██╔██╔══╝░████║░░██╔══██╗╚█║██╔══██╗██╔══██╗██╔══██╗██║██║██║\n"
							+ "╚██████╗░██╔██║░░██║░░██║░╚╝██║░░██║██║░░██║██║░░██║██║██║██║\n"
							+ "░╚═██╔██╗╚═╝██║░░██║░░██║░░░██║░░██║██║░░██║██║░░██║╚═╝╚═╝╚═╝\n"
							+ "███████╔╝███████╗╚█████╔╝░░░╚█████╔╝╚█████╔╝╚█████╔╝██╗██╗██╗\n"
							+ "╚══════╝░╚══════╝░╚════╝░░░░░╚════╝░░╚════╝░░╚════╝░╚═╝╚═╝╚═╝\n \n"
							+ "░█████╗░░█████╗░███╗░░██╗░██████╗░██████╗░░█████╗░████████╗██╗░░░██╗██╗░░░░░░█████╗░████████╗██╗░█████╗░███╗░░██╗░██████╗██╗\n"
							+ "██╔══██╗██╔══██╗████╗░██║██╔════╝░██╔══██╗██╔══██╗╚══██╔══╝██║░░░██║██║░░░░░██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║██╔════╝██║\n"
							+ "██║░░╚═╝██║░░██║██╔██╗██║██║░░██╗░██████╔╝███████║░░░██║░░░██║░░░██║██║░░░░░███████║░░░██║░░░██║██║░░██║██╔██╗██║╚█████╗░██║\n"
							+ "██║░░██╗██║░░██║██║╚████║██║░░╚██╗██╔══██╗██╔══██║░░░██║░░░██║░░░██║██║░░░░░██╔══██║░░░██║░░░██║██║░░██║██║╚████║░╚═══██╗╚═╝\n"
							+ "╚█████╔╝╚█████╔╝██║░╚███║╚██████╔╝██║░░██║██║░░██║░░░██║░░░╚██████╔╝███████╗██║░░██║░░░██║░░░██║╚█████╔╝██║░╚███║██████╔╝██╗\n"
							+ "░╚════╝░░╚════╝░╚═╝░░╚══╝░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░░╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝╚═════╝░╚═╝");
			
		} else if(a1.getMoney() <= 0) {
			
			System.out.println(a1.getName() + " is a bankrupt. " + a2.getName() + " has won automatically, \n"
					+ "░█████╗░░█████╗░███╗░░██╗░██████╗░██████╗░░█████╗░████████╗██╗░░░██╗██╗░░░░░░█████╗░████████╗██╗░█████╗░███╗░░██╗░██████╗██╗\n"
					+ "██╔══██╗██╔══██╗████╗░██║██╔════╝░██╔══██╗██╔══██╗╚══██╔══╝██║░░░██║██║░░░░░██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║██╔════╝██║\n"
					+ "██║░░╚═╝██║░░██║██╔██╗██║██║░░██╗░██████╔╝███████║░░░██║░░░██║░░░██║██║░░░░░███████║░░░██║░░░██║██║░░██║██╔██╗██║╚█████╗░██║\n"
					+ "██║░░██╗██║░░██║██║╚████║██║░░╚██╗██╔══██╗██╔══██║░░░██║░░░██║░░░██║██║░░░░░██╔══██║░░░██║░░░██║██║░░██║██║╚████║░╚═══██╗╚═╝\n"
					+ "╚█████╔╝╚█████╔╝██║░╚███║╚██████╔╝██║░░██║██║░░██║░░░██║░░░╚██████╔╝███████╗██║░░██║░░░██║░░░██║╚█████╔╝██║░╚███║██████╔╝██╗\n"
					+ "░╚════╝░░╚════╝░╚═╝░░╚══╝░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░░╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝╚═════╝░╚═╝");
			
		} else if(a2.getMoney() >= 10000) {
			
			System.out.println("\n\n"
					+ "███████╗██╗███╗░░██╗██╗░██████╗██╗░░██╗██╗\n"
					+ "██╔════╝██║████╗░██║██║██╔════╝██║░░██║██║\n"
					+ "█████╗░░██║██╔██╗██║██║╚█████╗░███████║██║\n"
					+ "██╔══╝░░██║██║╚████║██║░╚═══██╗██╔══██║╚═╝\n"
					+ "██║░░░░░██║██║░╚███║██║██████╔╝██║░░██║██╗\n"
					+ "╚═╝░░░░░╚═╝╚═╝░░╚══╝╚═╝╚═════╝░╚═╝░░╚═╝╚═╝\n\n" + a2.getName() + " has earned more than \n\n"
							+ "░███████╗░░███╗░░░█████╗░██╗░█████╗░░█████╗░░█████╗░██╗██╗██╗\n"
							+ "██╔██╔══╝░████║░░██╔══██╗╚█║██╔══██╗██╔══██╗██╔══██╗██║██║██║\n"
							+ "╚██████╗░██╔██║░░██║░░██║░╚╝██║░░██║██║░░██║██║░░██║██║██║██║\n"
							+ "░╚═██╔██╗╚═╝██║░░██║░░██║░░░██║░░██║██║░░██║██║░░██║╚═╝╚═╝╚═╝\n"
							+ "███████╔╝███████╗╚█████╔╝░░░╚█████╔╝╚█████╔╝╚█████╔╝██╗██╗██╗\n"
							+ "╚══════╝░╚══════╝░╚════╝░░░░░╚════╝░░╚════╝░░╚════╝░╚═╝╚═╝╚═╝\n \n"
							+ "░█████╗░░█████╗░███╗░░██╗░██████╗░██████╗░░█████╗░████████╗██╗░░░██╗██╗░░░░░░█████╗░████████╗██╗░█████╗░███╗░░██╗░██████╗██╗\n"
							+ "██╔══██╗██╔══██╗████╗░██║██╔════╝░██╔══██╗██╔══██╗╚══██╔══╝██║░░░██║██║░░░░░██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║██╔════╝██║\n"
							+ "██║░░╚═╝██║░░██║██╔██╗██║██║░░██╗░██████╔╝███████║░░░██║░░░██║░░░██║██║░░░░░███████║░░░██║░░░██║██║░░██║██╔██╗██║╚█████╗░██║\n"
							+ "██║░░██╗██║░░██║██║╚████║██║░░╚██╗██╔══██╗██╔══██║░░░██║░░░██║░░░██║██║░░░░░██╔══██║░░░██║░░░██║██║░░██║██║╚████║░╚═══██╗╚═╝\n"
							+ "╚█████╔╝╚█████╔╝██║░╚███║╚██████╔╝██║░░██║██║░░██║░░░██║░░░╚██████╔╝███████╗██║░░██║░░░██║░░░██║╚█████╔╝██║░╚███║██████╔╝██╗\n"
							+ "░╚════╝░░╚════╝░╚═╝░░╚══╝░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░░╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝╚═════╝░╚═╝");
			
		} else if(a2.getMoney() <= 0) {
			
			System.out.println(a2.getName() + " is a bankrupt. " + a1.getName() + " has won automatically, \n"
					+ "░█████╗░░█████╗░███╗░░██╗░██████╗░██████╗░░█████╗░████████╗██╗░░░██╗██╗░░░░░░█████╗░████████╗██╗░█████╗░███╗░░██╗░██████╗██╗\n"
					+ "██╔══██╗██╔══██╗████╗░██║██╔════╝░██╔══██╗██╔══██╗╚══██╔══╝██║░░░██║██║░░░░░██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║██╔════╝██║\n"
					+ "██║░░╚═╝██║░░██║██╔██╗██║██║░░██╗░██████╔╝███████║░░░██║░░░██║░░░██║██║░░░░░███████║░░░██║░░░██║██║░░██║██╔██╗██║╚█████╗░██║\n"
					+ "██║░░██╗██║░░██║██║╚████║██║░░╚██╗██╔══██╗██╔══██║░░░██║░░░██║░░░██║██║░░░░░██╔══██║░░░██║░░░██║██║░░██║██║╚████║░╚═══██╗╚═╝\n"
					+ "╚█████╔╝╚█████╔╝██║░╚███║╚██████╔╝██║░░██║██║░░██║░░░██║░░░╚██████╔╝███████╗██║░░██║░░░██║░░░██║╚█████╔╝██║░╚███║██████╔╝██╗\n"
					+ "░╚════╝░░╚════╝░╚═╝░░╚══╝░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░░╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝╚═════╝░╚═╝");
		}
	}
	
	//This is the same method as the twoPlayersGame, but the only difference is that the data is loaded from the files.
	public static void twoPlayersGameFile(Scanner input) {
		
		Random number = new Random();
		CardsQueue cq = new CardsQueue(10);
		CardsQueue tq = new CardsQueue(10);
		String name1, name2;
		
		//for loop to fill the queue with random card values
		for(int i = 0; i < 10; i++) {
			
			cq.enqueue(number.nextInt(5)+1);
			tq.enqueue(number.nextInt(5)+1);
		}

		System.out.println("Enter the file destination for the player 1:");
		name1 = input.next();
		System.out.println("Enter the file destination for the player 2:");
		name2 = input.next();
				
		Jail j1 = new Jail();
		Jail j2 = new Jail();
		
		Board board1 = new Board();
		
		Player a1 = loadPlayer(name1, board1);
		Player a2 = loadPlayer(name2, board1);
		
		System.out.println("\n\n"
				+ "░█████╗░░█████╗░███╗░░██╗████████╗██╗███╗░░██╗██╗░░░██╗███████╗██╗\n"
				+ "██╔══██╗██╔══██╗████╗░██║╚══██╔══╝██║████╗░██║██║░░░██║██╔════╝██║\n"
				+ "██║░░╚═╝██║░░██║██╔██╗██║░░░██║░░░██║██╔██╗██║██║░░░██║█████╗░░██║\n"
				+ "██║░░██╗██║░░██║██║╚████║░░░██║░░░██║██║╚████║██║░░░██║██╔══╝░░╚═╝\n"
				+ "╚█████╔╝╚█████╔╝██║░╚███║░░░██║░░░██║██║░╚███║╚██████╔╝███████╗██╗\n"
				+ "░╚════╝░░╚════╝░╚═╝░░╚══╝░░░╚═╝░░░╚═╝╚═╝░░╚══╝░╚═════╝░╚══════╝╚═╝\n\n");
		
		//do-while loop until someone wins the game.
		do {
			
			playerTurn(board1, a1, input, number, cq, tq, j1);
			
			playerTurn(board1, a2, input, number, cq, tq, j2);
				
		}while(a1.getMoney() < 10000 && a2.getMoney() < 10000 && a1.getMoney() > 0 && a2.getMoney() > 0);
		
		//if-else statement prints different messages depending on who has won and how.
		if(a1.getMoney() >= 10000) {
			
			System.out.println("\n\n"
					+ "███████╗██╗███╗░░██╗██╗░██████╗██╗░░██╗██╗\n"
					+ "██╔════╝██║████╗░██║██║██╔════╝██║░░██║██║\n"
					+ "█████╗░░██║██╔██╗██║██║╚█████╗░███████║██║\n"
					+ "██╔══╝░░██║██║╚████║██║░╚═══██╗██╔══██║╚═╝\n"
					+ "██║░░░░░██║██║░╚███║██║██████╔╝██║░░██║██╗\n"
					+ "╚═╝░░░░░╚═╝╚═╝░░╚══╝╚═╝╚═════╝░╚═╝░░╚═╝╚═╝\n\n" + a1.getName() + " has earned more than \n\n"
							+ "░███████╗░░███╗░░░█████╗░██╗░█████╗░░█████╗░░█████╗░██╗██╗██╗\n"
							+ "██╔██╔══╝░████║░░██╔══██╗╚█║██╔══██╗██╔══██╗██╔══██╗██║██║██║\n"
							+ "╚██████╗░██╔██║░░██║░░██║░╚╝██║░░██║██║░░██║██║░░██║██║██║██║\n"
							+ "░╚═██╔██╗╚═╝██║░░██║░░██║░░░██║░░██║██║░░██║██║░░██║╚═╝╚═╝╚═╝\n"
							+ "███████╔╝███████╗╚█████╔╝░░░╚█████╔╝╚█████╔╝╚█████╔╝██╗██╗██╗\n"
							+ "╚══════╝░╚══════╝░╚════╝░░░░░╚════╝░░╚════╝░░╚════╝░╚═╝╚═╝╚═╝\n \n"
							+ "░█████╗░░█████╗░███╗░░██╗░██████╗░██████╗░░█████╗░████████╗██╗░░░██╗██╗░░░░░░█████╗░████████╗██╗░█████╗░███╗░░██╗░██████╗██╗\n"
							+ "██╔══██╗██╔══██╗████╗░██║██╔════╝░██╔══██╗██╔══██╗╚══██╔══╝██║░░░██║██║░░░░░██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║██╔════╝██║\n"
							+ "██║░░╚═╝██║░░██║██╔██╗██║██║░░██╗░██████╔╝███████║░░░██║░░░██║░░░██║██║░░░░░███████║░░░██║░░░██║██║░░██║██╔██╗██║╚█████╗░██║\n"
							+ "██║░░██╗██║░░██║██║╚████║██║░░╚██╗██╔══██╗██╔══██║░░░██║░░░██║░░░██║██║░░░░░██╔══██║░░░██║░░░██║██║░░██║██║╚████║░╚═══██╗╚═╝\n"
							+ "╚█████╔╝╚█████╔╝██║░╚███║╚██████╔╝██║░░██║██║░░██║░░░██║░░░╚██████╔╝███████╗██║░░██║░░░██║░░░██║╚█████╔╝██║░╚███║██████╔╝██╗\n"
							+ "░╚════╝░░╚════╝░╚═╝░░╚══╝░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░░╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝╚═════╝░╚═╝");
			
		} else if(a1.getMoney() <= 0) {
			
			System.out.println(a1.getName() + " is a bankrupt. " + a2.getName() + " has won automatically, \n"
					+ "░█████╗░░█████╗░███╗░░██╗░██████╗░██████╗░░█████╗░████████╗██╗░░░██╗██╗░░░░░░█████╗░████████╗██╗░█████╗░███╗░░██╗░██████╗██╗\n"
					+ "██╔══██╗██╔══██╗████╗░██║██╔════╝░██╔══██╗██╔══██╗╚══██╔══╝██║░░░██║██║░░░░░██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║██╔════╝██║\n"
					+ "██║░░╚═╝██║░░██║██╔██╗██║██║░░██╗░██████╔╝███████║░░░██║░░░██║░░░██║██║░░░░░███████║░░░██║░░░██║██║░░██║██╔██╗██║╚█████╗░██║\n"
					+ "██║░░██╗██║░░██║██║╚████║██║░░╚██╗██╔══██╗██╔══██║░░░██║░░░██║░░░██║██║░░░░░██╔══██║░░░██║░░░██║██║░░██║██║╚████║░╚═══██╗╚═╝\n"
					+ "╚█████╔╝╚█████╔╝██║░╚███║╚██████╔╝██║░░██║██║░░██║░░░██║░░░╚██████╔╝███████╗██║░░██║░░░██║░░░██║╚█████╔╝██║░╚███║██████╔╝██╗\n"
					+ "░╚════╝░░╚════╝░╚═╝░░╚══╝░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░░╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝╚═════╝░╚═╝");
			
		} else if(a2.getMoney() >= 10000) {
			
			System.out.println("\n\n"
					+ "███████╗██╗███╗░░██╗██╗░██████╗██╗░░██╗██╗\n"
					+ "██╔════╝██║████╗░██║██║██╔════╝██║░░██║██║\n"
					+ "█████╗░░██║██╔██╗██║██║╚█████╗░███████║██║\n"
					+ "██╔══╝░░██║██║╚████║██║░╚═══██╗██╔══██║╚═╝\n"
					+ "██║░░░░░██║██║░╚███║██║██████╔╝██║░░██║██╗\n"
					+ "╚═╝░░░░░╚═╝╚═╝░░╚══╝╚═╝╚═════╝░╚═╝░░╚═╝╚═╝\n\n" + a2.getName() + " has earned more than \n\n"
							+ "░███████╗░░███╗░░░█████╗░██╗░█████╗░░█████╗░░█████╗░██╗██╗██╗\n"
							+ "██╔██╔══╝░████║░░██╔══██╗╚█║██╔══██╗██╔══██╗██╔══██╗██║██║██║\n"
							+ "╚██████╗░██╔██║░░██║░░██║░╚╝██║░░██║██║░░██║██║░░██║██║██║██║\n"
							+ "░╚═██╔██╗╚═╝██║░░██║░░██║░░░██║░░██║██║░░██║██║░░██║╚═╝╚═╝╚═╝\n"
							+ "███████╔╝███████╗╚█████╔╝░░░╚█████╔╝╚█████╔╝╚█████╔╝██╗██╗██╗\n"
							+ "╚══════╝░╚══════╝░╚════╝░░░░░╚════╝░░╚════╝░░╚════╝░╚═╝╚═╝╚═╝\n \n"
							+ "░█████╗░░█████╗░███╗░░██╗░██████╗░██████╗░░█████╗░████████╗██╗░░░██╗██╗░░░░░░█████╗░████████╗██╗░█████╗░███╗░░██╗░██████╗██╗\n"
							+ "██╔══██╗██╔══██╗████╗░██║██╔════╝░██╔══██╗██╔══██╗╚══██╔══╝██║░░░██║██║░░░░░██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║██╔════╝██║\n"
							+ "██║░░╚═╝██║░░██║██╔██╗██║██║░░██╗░██████╔╝███████║░░░██║░░░██║░░░██║██║░░░░░███████║░░░██║░░░██║██║░░██║██╔██╗██║╚█████╗░██║\n"
							+ "██║░░██╗██║░░██║██║╚████║██║░░╚██╗██╔══██╗██╔══██║░░░██║░░░██║░░░██║██║░░░░░██╔══██║░░░██║░░░██║██║░░██║██║╚████║░╚═══██╗╚═╝\n"
							+ "╚█████╔╝╚█████╔╝██║░╚███║╚██████╔╝██║░░██║██║░░██║░░░██║░░░╚██████╔╝███████╗██║░░██║░░░██║░░░██║╚█████╔╝██║░╚███║██████╔╝██╗\n"
							+ "░╚════╝░░╚════╝░╚═╝░░╚══╝░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░░╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝╚═════╝░╚═╝");
			
		} else if(a2.getMoney() <= 0) {
			
			System.out.println(a2.getName() + " is a bankrupt. " + a1.getName() + " has won automatically, \n"
					+ "░█████╗░░█████╗░███╗░░██╗░██████╗░██████╗░░█████╗░████████╗██╗░░░██╗██╗░░░░░░█████╗░████████╗██╗░█████╗░███╗░░██╗░██████╗██╗\n"
					+ "██╔══██╗██╔══██╗████╗░██║██╔════╝░██╔══██╗██╔══██╗╚══██╔══╝██║░░░██║██║░░░░░██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║██╔════╝██║\n"
					+ "██║░░╚═╝██║░░██║██╔██╗██║██║░░██╗░██████╔╝███████║░░░██║░░░██║░░░██║██║░░░░░███████║░░░██║░░░██║██║░░██║██╔██╗██║╚█████╗░██║\n"
					+ "██║░░██╗██║░░██║██║╚████║██║░░╚██╗██╔══██╗██╔══██║░░░██║░░░██║░░░██║██║░░░░░██╔══██║░░░██║░░░██║██║░░██║██║╚████║░╚═══██╗╚═╝\n"
					+ "╚█████╔╝╚█████╔╝██║░╚███║╚██████╔╝██║░░██║██║░░██║░░░██║░░░╚██████╔╝███████╗██║░░██║░░░██║░░░██║╚█████╔╝██║░╚███║██████╔╝██╗\n"
					+ "░╚════╝░░╚════╝░╚═╝░░╚══╝░╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝░░░╚═╝░░░░╚═════╝░╚══════╝╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝╚═════╝░╚═╝");
		}
	}
	
	//This is the method that contains the turn player has to do. This is where he will choose whether he wants to roll a dice or checking anything.
	public static void playerTurn(Board board1, Player a1, Scanner input, Random number, CardsQueue cq, CardsQueue tq, Jail j1) {
		
		int choose, choose2;
		DecimalFormat foo = new DecimalFormat("#,###.##");
		
		System.out.println(a1.getName() + ", it's your turn! You are currently at position " + a1.getPosition() + ".\n");
		
		//if player hasn't answered the question in the prison, he automatically goes there again.
		if(j1.check() == 0) {
			
			System.out.println("\nLooks like you haven't answered prison question, so you must stay here for a little longer.\n");
			a1.setPosition(6);
			
		} else {
			
			System.out.println("This are your earnings from the previous player's move: $" + board1.getRent() + "\n");
			a1.setMoney(a1.getMoney() + board1.getRent());
			
			//do-while loop to avoid wrong inputs.
			do {
				
				System.out.println("1. Roll a dice\n2. Check your balance and properties\n3. Buy houses on your properties\n4. Look at the map\n5. Look at your properties from cheapest to the most expensive in prices\n6. Convert your balance into different currencies\n7. Save data to a file");
				choose = input.nextInt();
				
				//if-else statement initiates one of the selected menu options.
				//if player selects second option, he can check his balance and properties.
				if(choose == 2) {
					
					System.out.println("\n" + a1);
					
				//if player selects third option, he is presented with a house-building menu.
				} else if(choose == 3) {
					
					buildHouses(board1, a1, input);
				
				//if player selects fourth option, he is presented with the map.	
				} else if(choose == 4) {
					
					String[][] mapPos = {{"11", "12", "13", "14", "15", "16"}, {"10", "  ", "  ", "  ", "  ", "17"}, {"9 ", "  ", "  ", "  ", "  ", "18"}, {"8 ", "  ", "  ", "  ", "  ", "19"}, {"7 ", "  ", "  ", "  ", "  ", "20"}, {"6 ", "5 ", "4 ", "3 ", "2 ", "1 "}};
					
					System.out.println("\nHere are the positions of the properties\n");
					
					for(int i = 0; i < mapPos.length; i++) {
						for(int j = 0; j < mapPos[i].length; j++) {
							
							System.out.print(mapPos[i][j] + " ");
						}
						System.out.println();
					}
					
					System.out.println("\n1. Go!\n2. IBM\n3. Ericsson\n4. Chance Card\n5. Razer\n6. Jail\n7. Staples\n8. Intel\n9. Chance Card\n10. ManageEngine\n11. Free Parking\n12. Treasure Chest Card\n13. Amazon\n14. HP\n15. Belking\n16. Free Parking\n17. Honeywell\n18. Apple\n19. Dell\n20. Samsung\n");
				
				//if player selects fifth option, he can see his properties from cheapest to the most expensive ones.	
				} else if(choose == 5) {
					
					int[] a = a1.getPropertiesPrices();					
					int[] newa = bubbleSort(a);
					
					System.out.println("\nHere are the prices of your properties from lowest to highest: ");
					
					for(int i = 0; i < newa.length; i++) {
						
						System.out.print((i+1) + ") " + newa[i] + "\n");
					}
					
					System.out.println("\n\n");
					
				//if player selects sixth option, he can choose what currency he wants to convert his money to.	
				} else if(choose == 6) {
					
					//do-while loop to avoid wrong inputs.
					do {
						
						System.out.println("\n1. Convert to Hryvnas\n2. Convert to Euros\n3. Convert to US Dollars");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							System.out.println("\nYour balance in Hryvnas is ₴" + foo.format(a1.convertToHryvnas(a1.getMoney())) + "\n");
							
						} else if(choose2 == 2) {
							
							System.out.println("\nYou balance in Euros is €" + foo.format(a1.convertToEuros(a1.getMoney())) + "\n");
							
						} else if(choose2 == 3) {
							
							System.out.println("\nYour balance in US Dollars is $" + foo.format(a1.convertToUSDollars(a1.getMoney())) + "\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 3);	
					
				//if player selects seventh option, all of his data will be saved to a file he provides.	
				} else if(choose == 7) {
				
					System.out.println();
					saveData(a1, input);
				
				//else menu is printed again.	
				} else if(choose < 1 || choose > 7) {
					
					System.out.println("\nInvalid input, please try again.\n");
				}
				
			}while(choose != 1);
			
			int dice = number.nextInt(10)+1;
			
			System.out.println("\n\nYou have rolled " + dice + ".\n");
			a1.setPosition(a1.getPosition() + dice);
			
			//if player crosses the go location, money will be added to his account.
			if(a1.getPosition() > 21) {
				
				System.out.println("\nYou have crossed Go! location. You earn $400\n");
				a1.setMoney(a1.getMoney() + 400);
				a1.setPosition(a1.getPosition() - 20);
				
			} else if(a1.getPosition() == 21) {
				
				a1.setPosition(1);
			}
			
			System.out.println("\n\nYou have ended up at position " + a1.getPosition() + "\n");
		
		}
		
		moveOnBoard(board1, a1, input, cq, tq, j1);
	}	
	
	//Method which has loads of different options depending on what position has player landed on.
	public static void moveOnBoard(Board board1, Player a1, Scanner input, CardsQueue cq, CardsQueue tq, Jail j1) {
		
		int choose2;
		Random number = new Random();
		
		//do-while loop to repeat if you go through the go location again..
		do {
			
			//HUGE if-else statement on 20 different options depending on players position.
			//if player lands on position 1, he gains money
			//if player lands on position 2, this is property
			//if player lands on position 3, this is property
			//if player lands on position 4, this is chance card
			//if player lands on position 5, this is property
			//if player lands on position 6, he goes to jail
			//if player lands on position 7, this is property
			//if player lands on position 8, this is property
			//if player lands on position 9, this is chance card
			//if player lands on position 10, this is property
			//if player lands on position 11, he is on the free parking, and gets to do nothing
			//if player lands on position 12, this is property
			//if player lands on position 13, this is property
			//if player lands on position 14, this is property
			//if player lands on position 15, this is property
			//if player lands on position 16, he is on the free parking, and gets to do nothing
			//if player lands on position 17, this is property
			//if player lands on position 18, this is property
			//if player lands on position 19, this is property
			//if player lands on position 20, this is property
			if(a1.getPosition() == 1) {
				
				System.out.println("\nYou are on Go! location. You earn $400\n");
				a1.setMoney(a1.getMoney() + 400);
				
			} else if(a1.getPosition() == 2) {
				
				System.out.println("You are at IBM location.");
				
				if(board1.toIBM().getAvailability() == 1) {
					
					do {
						
						System.out.println("\nDo you want to buy this property?\nPrice:  " + board1.toIBM().getPrice() + "\nRent: " + board1.toIBM().getRent() + "\n" + "\n1. Yes\n2. No");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							if(a1.getMoney() < board1.toIBM().getPrice()) {
								
								System.out.println("\nSorry, you don't have enough money to make a purchase.\n");
								
							} else {
								
								System.out.println("\n\n\nCongratulations on buying this property, you are now the owner!\n\n");
								a1.addProperty(board1.toIBM());
								board1.toIBM().setAvailability(0);
								a1.addWhitePoints();
								a1.setMoney(a1.getMoney() - board1.toIBM().getPrice());
								a1.addIBM();
								
							}
							
						} else if(choose2 == 2) {
							
							System.out.println("\n\nThat's sad that you don't want to buy this property.\n\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 2);
					
				} else {
					
					if(a1.checkIBM() == 0) {
						
						System.out.println("\nOh no. You are currently at someone's property.\nYou have to pay rent.\nIf you own this property, your money loss will be refunded when it's your turn\n");
						a1.setMoney(a1.getMoney() - board1.toIBM().getRent());
						board1.payRent(board1.toIBM().getRent());
						
					} else {
						
						System.out.println("\nThis is your property, you get to stay here untill your next move.\n");
					}
				}
				
			} else if(a1.getPosition() == 3) {
				
				System.out.println("You are at Ericsson location.");
				
				if(board1.toEricsson().getAvailability() == 1) {
					
					do {
						
						System.out.println("\nDo you want to buy this property?\nPrice: " + board1.toEricsson().getPrice() + "\nRent: " + board1.toEricsson().getRent() + "\n\n1. Yes\n2. No");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							if(a1.getMoney() < board1.toEricsson().getPrice()) {
								
								System.out.println("\nSorry, you don't have enough money to make a purchase.\n");
								
							} else {
								
								System.out.println("\n\nCongratulations on buying this property, you are now the owner!\n");
								a1.addProperty(board1.toEricsson());
								board1.toEricsson().setAvailability(0);
								a1.addWhitePoints();
								a1.setMoney(a1.getMoney() - board1.toEricsson().getPrice());
								a1.addEricsson();
							}
							
						} else if(choose2 == 2) {
							
							System.out.println("\nThat's sad that you don't want to buy this property.\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 2);
					
				} else {
					
					if(a1.checkEricsson() == 0) {
						
						System.out.println("\nOh no. You are currently at someone's property.\nYou have to pay rent.\nIf you own this property, your money loss will be refunded when it's your turn\n");
						a1.setMoney(a1.getMoney() - board1.toEricsson().getRent());
						board1.payRent(board1.toEricsson().getRent());
						
					} else {
						
						System.out.println("\nThis is your property, you get to stay here untill your next move.\n");
					}
				}
				
			} else if(a1.getPosition() == 4) {
				
				System.out.println("You have ended up at Chance card location.\nYou get to pull out Chance card.");
				int temp = cq.front();
				Chance c = new Chance(temp, a1);
				c.wCard();
				cq.dequeue();
				cq.enqueue(temp);
				
			} else if(a1.getPosition() == 5) {
				
				System.out.println("You are at Razer location.");
				
				if(board1.toRazer().getAvailability() == 1) {
					
					do {
						
						System.out.println("\nDo you want to buy this property?\nPrice: " + board1.toRazer().getPrice() + "\nRent: " + board1.toRazer().getRent() + "\n\n1. Yes\n2. No");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							if(a1.getMoney() < board1.toRazer().getPrice()) {
								
								System.out.println("\nSorry, you don't have enough money to make a purchase.\n");
								
							} else {
								
								System.out.println("\n\nCongratulations on buying this property, you are now the owner!\n");
								a1.addProperty(board1.toRazer());
								board1.toRazer().setAvailability(0);
								a1.addGreenPoints();
								a1.setMoney(a1.getMoney() - board1.toRazer().getPrice());
								a1.addRazer();
							}
							
						} else if(choose2 == 2) {
							
							System.out.println("\nThat's sad that you don't want to buy this property.\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 2);
					
				} else {
					
					if(a1.checkRazer() == 0) {
						
						System.out.println("\nOh no. You are currently at someone's property.\nYou have to pay rent.\nIf you own this property, your money loss will be refunded when it's your turn\n");
						a1.setMoney(a1.getMoney() - board1.toRazer().getRent());
						board1.payRent(board1.toRazer().getRent());
						
					} else {
						
						System.out.println("\nThis is your property, you get to stay here untill your next move.\n");
					}
				}
				
			} else if(a1.getPosition() == 6) {
				
				System.out.println("You are in Jail, what a shame");
				j1.PrisonQuiz(number.nextInt(5)+1);
				
			} else if(a1.getPosition() == 7) {
				
				System.out.println("You are at Staples location.");
				
				if(board1.toStaples().getAvailability() == 1) {
					
					do {
						
						System.out.println("\nDo you want to buy this property?\nPrice: " + board1.toStaples().getPrice() + "\nRent: " + board1.toStaples().getRent() + "\n\n1. Yes\n2. No");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							if(a1.getMoney() < board1.toStaples().getPrice()) {
								
								System.out.println("\nSorry, you don't have enough money to make a purchase.\n");
								
							} else {
								
								System.out.println("\n\nCongratulations on buying this property, you are now the owner!\n");
								a1.addProperty(board1.toStaples());
								board1.toStaples().setAvailability(0);
								a1.addGreenPoints();
								a1.setMoney(a1.getMoney() - board1.toStaples().getPrice());
								a1.addStaples();
							}
							
						} else if(choose2 == 2) {
							
							System.out.println("\nThat's sad that you don't want to buy this property.\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 2);
					
				} else {
					
					if(a1.checkStaples() == 0) {
						
						System.out.println("\nOh no. You are currently at someone's property.\nYou have to pay rent.\nIf you own this property, your money loss will be refunded when it's your turn\n");
						a1.setMoney(a1.getMoney() - board1.toStaples().getRent());
						board1.payRent(board1.toStaples().getRent());
						
					} else {
						
						System.out.println("\nThis is your property, you get to stay here untill your next move.\n");
					}
				}
				
			} else if(a1.getPosition() == 8) {
				
				System.out.println("You are at Intel location.");
				
				if(board1.toIntel().getAvailability() == 1) {
					
					do {
						
						System.out.println("\nDo you want to buy this property?\nPrice: " + board1.toIntel().getPrice() + "\nRent: " + board1.toIntel().getRent() + "\n\n1. Yes\n2. No");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							if(a1.getMoney() < board1.toIntel().getPrice()) {
								
								System.out.println("\nSorry, you don't have enough money to make a purchase.\n");
								
							} else {
								
								System.out.println("\n\nCongratulations on buying this property, you are now the owner!\n");
								a1.addProperty(board1.toIntel());
								board1.toIntel().setAvailability(0);
								a1.addGreenPoints();
								a1.setMoney(a1.getMoney() - board1.toIntel().getPrice());
								a1.addIntel();
							}
							
						} else if(choose2 == 2) {
							
							System.out.println("\nThat's sad that you don't want to buy this property.\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 2);
					
				} else {
					
					if(a1.checkIntel() == 0) {
						
						System.out.println("\nOh no. You are currently at someone's property.\nYou have to pay rent.\nIf you own this property, your money loss will be refunded when it's your turn\n");
						a1.setMoney(a1.getMoney() - board1.toIntel().getRent());
						board1.payRent(board1.toIntel().getRent());
						
					} else {
						
						System.out.println("\nThis is your property, you get to stay here untill your next move.\n");
					}
				}
				
			} else if(a1.getPosition() == 9) {
				
				System.out.println("You have ended up at Chance card location.\nYou get to pull out Chance card.");
				int temp = cq.front();
				Chance c = new Chance(temp, a1);
				c.wCard();
				cq.dequeue();
				cq.enqueue(temp);
				
			} else if(a1.getPosition() == 10) {
				
				System.out.println("You are at ManageEngine location.");
				
				if(board1.toManageEngine().getAvailability() == 1) {
					
					do {
						
						System.out.println("\nDo you want to buy this property?\nPrice: " + board1.toManageEngine().getPrice() + "\nRent: " + board1.toManageEngine().getRent() + "\n\n1. Yes\n2. No");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							if(a1.getMoney() < board1.toManageEngine().getPrice()) {
								
								System.out.println("\nSorry, you don't have enough money to make a purchase.\n");
								
							} else {
								
								System.out.println("\n\nCongratulations on buying this property, you are now the owner!\n");
								a1.addProperty(board1.toManageEngine());
								board1.toManageEngine().setAvailability(0);
								a1.addRedPoints();
								a1.setMoney(a1.getMoney() - board1.toManageEngine().getPrice());
								a1.addManageEngine();
							}
							
						} else if(choose2 == 2) {
							
							System.out.println("\nThat's sad that you don't want to buy this property.\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 2);
					
				} else {
					
					if(a1.checkManageEngine() == 0) {
						
						System.out.println("\nOh no. You are currently at someone's property.\nYou have to pay rent.\nIf you own this property, your money loss will be refunded when it's your turn\n");
						a1.setMoney(a1.getMoney() - board1.toManageEngine().getRent());
						board1.payRent(board1.toManageEngine().getRent());
						
					} else {
						
						System.out.println("\nThis is your property, you get to stay here untill your next move.\n");
					}
				}
				
			} else if(a1.getPosition() == 11) {
				
				System.out.println("Free parking. Enjoy your stay!\n");
				
			} else if(a1.getPosition() == 12) {
				
				System.out.println("You have ended up at Treasure Chest card location.\nYou get to pull out Treasuer Chest card.");
				int temp = tq.front();
				TreasureChest c = new TreasureChest(temp, a1);
				c.wCard();
				tq.dequeue();
				tq.enqueue(temp);
				
			} else if(a1.getPosition() == 13) {
				
				System.out.println("You are at Amazon location.");
				
				if(board1.toAmazon().getAvailability() == 1) {
					
					do {
						
						System.out.println("\nDo you want to buy this property?\nPrice: " + board1.toAmazon().getPrice() + "\nRent: " + board1.toAmazon().getRent() + "\n\n1. Yes\n2. No");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							if(a1.getMoney() < board1.toAmazon().getPrice()) {
								
								System.out.println("\nSorry, you don't have enough money to make a purchase.\n");
								
							} else {
								
								System.out.println("\n\nCongratulations on buying this property, you are now the owner!\n");
								a1.addProperty(board1.toAmazon());
								board1.toAmazon().setAvailability(0);
								a1.addWhitePoints();
								a1.setMoney(a1.getMoney() - board1.toAmazon().getPrice());
								a1.addAmazon();
							}
							
						} else if(choose2 == 2) {
							
							System.out.println("\nThat's sad that you don't want to buy this property.\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 2);
					
				} else {
					
					if(a1.checkAmazon() == 0) {
						
						System.out.println("\nOh no. You are currently at someone's property.\nYou have to pay rent.\nIf you own this property, your money loss will be refunded when it's your turn\n");
						a1.setMoney(a1.getMoney() - board1.toAmazon().getRent());
						board1.payRent(board1.toAmazon().getRent());
						
					} else {
						
						System.out.println("\nThis is your property, you get to stay here untill your next move.\n");
					}
				}
				
			} else if(a1.getPosition() == 14) {
				
				System.out.println("You are at HP location.");
				
				if(board1.toHP().getAvailability() == 1) {
					
					do {
						
						System.out.println("\nDo you want to buy this property?\nPrice: " + board1.toHP().getPrice() + "\nRent: " + board1.toHP().getRent() + "\n\n1. Yes\n2. No");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							if(a1.getMoney() < board1.toHP().getPrice()) {
								
								System.out.println("\nSorry, you don't have enough money to make a purchase.\n");
								
							} else {
								
								System.out.println("\n\nCongratulations on buying this property, you are now the owner!\n");
								a1.addProperty(board1.toHP());
								board1.toHP().setAvailability(0);
								a1.addRedPoints();
								a1.setMoney(a1.getMoney() - board1.toHP().getPrice());
								a1.addHP();
							}
							
						} else if(choose2 == 2) {
							
							System.out.println("\nThat's sad that you don't want to buy this property.\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 2);
					
				} else {
					
					if(a1.checkHP() == 0) {
						
						System.out.println("\nOh no. You are currently at someone's property.\nYou have to pay rent.\nIf you own this property, your money loss will be refunded when it's your turn\n");
						a1.setMoney(a1.getMoney() - board1.toHP().getRent());
						board1.payRent(board1.toHP().getRent());
						
					} else {
						
						System.out.println("\nThis is your property, you get to stay here untill your next move.\n");
					}
				}
				
			} else if(a1.getPosition() == 15) {
				
				System.out.println("You are at Belking location.");
				
				if(board1.toBelking().getAvailability() == 1) {
					
					do {
						
						System.out.println("\nDo you want to buy this property?\nPrice: " + board1.toBelking().getPrice() + "\nRent: " + board1.toBelking().getRent() + "\n\n1. Yes\n2. No");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							if(a1.getMoney() < board1.toBelking().getPrice()) {
								
								System.out.println("\nSorry, you don't have enough money to make a purchase.\n");
								
							} else {
								
								System.out.println("\n\nCongratulations on buying this property, you are now the owner!\n");
								a1.addProperty(board1.toBelking());
								board1.toBelking().setAvailability(0);
								a1.addYellowPoints();
								a1.setMoney(a1.getMoney() - board1.toBelking().getPrice());
								a1.addBelking();
							}
							
						} else if(choose2 == 2) {
							
							System.out.println("\nThat's sad that you don't want to buy this property.\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 2);
					
				} else {
					
					if(a1.checkBelking() == 0) {
						
						System.out.println("\nOh no. You are currently at someone's property.\nYou have to pay rent.\nIf you own this property, your money loss will be refunded when it's your turn\n");
						a1.setMoney(a1.getMoney() - board1.toBelking().getRent());
						board1.payRent(board1.toBelking().getRent());
						
					} else {
						
						System.out.println("\nThis is your property, you get to stay here untill your next move.\n");
					}
				}
				
			} else if(a1.getPosition() == 16) {
				
				System.out.println("Free parking. Enjoy your stay!\n");
				
			} else if(a1.getPosition() == 17) {
				
				System.out.println("You are at Honeywell location.");
				
				if(board1.toHoneywell().getAvailability() == 1) {
					
					do {
						
						System.out.println("\nDo you want to buy this property?\nPrice: " + board1.toHoneywell().getPrice() + "\nRent: " + board1.toHoneywell().getRent() + "\n\n1. Yes\n2. No");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							if(a1.getMoney() < board1.toHoneywell().getPrice()) {
								
								System.out.println("\nSorry, you don't have enough money to make a purchase.\n");
								
							} else {
								
								System.out.println("\n\nCongratulations on buying this property, you are now the owner!\n");
								a1.addProperty(board1.toHoneywell());
								board1.toHoneywell().setAvailability(0);
								a1.addYellowPoints();
								a1.setMoney(a1.getMoney() - board1.toHoneywell().getPrice());
								a1.addHoneywell();
							}
							
						} else if(choose2 == 2) {
							
							System.out.println("\nThat's sad that you don't want to buy this property.\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 2);
					
				} else {
					
					if(a1.checkHoneywell() == 0) {
						
						System.out.println("\nOh no. You are currently at someone's property.\nYou have to pay rent.\nIf you own this property, your money loss will be refunded when it's your turn\n");
						a1.setMoney(a1.getMoney() - board1.toHoneywell().getRent());
						board1.payRent(board1.toHoneywell().getRent());
						
					} else {
						
						System.out.println("\nThis is your property, you get to stay here untill your next move.\n");
					}
				}
				
			} else if(a1.getPosition() == 18) {
				
				System.out.println("You are at Apple location.");
				
				if(board1.toApple().getAvailability() == 1) {
					
					do {
						
						System.out.println("\nDo you want to buy this property?\nPrice: " + board1.toApple().getPrice() + "\nRent: " + board1.toApple().getRent() + "\n\n1. Yes\n2. No");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							if(a1.getMoney() < board1.toApple().getPrice()) {
								
								System.out.println("\nSorry, you don't have enough money to make a purchase.\n");
								
							} else {
								
								System.out.println("\n\nCongratulations on buying this property, you are now the owner!\n");
								a1.addProperty(board1.toApple());
								board1.toApple().setAvailability(0);
								a1.addBluePoints();
								a1.setMoney(a1.getMoney() - board1.toApple().getPrice());
								a1.addApple();
							}
							
						} else if(choose2 == 2) {
							
							System.out.println("\nThat's sad that you don't want to buy this property.\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 2);
					
				} else {
					
					if(a1.checkApple() == 0) {
						
						System.out.println("\nOh no. You are currently at someone's property.\nYou have to pay rent.\nIf you own this property, your money loss will be refunded when it's your turn\n");
						a1.setMoney(a1.getMoney() - board1.toApple().getRent());
						board1.payRent(board1.toApple().getRent());
						
					} else {
						
						System.out.println("\nThis is your property, you get to stay here untill your next move.\n");
					}
				}
				
			} else if(a1.getPosition() == 19) {
				
				System.out.println("You are at Dell location.");
				
				if(board1.toDell().getAvailability() == 1) {
					
					do {
						
						System.out.println("\nDo you want to buy this property?\nPrice: " + board1.toDell().getPrice() + "\nRent: " + board1.toDell().getRent() + "\n\n1. Yes\n2. No");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							if(a1.getMoney() < board1.toDell().getPrice()) {
								
								System.out.println("\nSorry, you don't have enough money to make a purchase.\n");
								
							} else {
								
								System.out.println("\n\nCongratulations on buying this property, you are now the owner!\n");
								a1.addProperty(board1.toDell());
								board1.toDell().setAvailability(0);
								a1.addYellowPoints();
								a1.setMoney(a1.getMoney() - board1.toDell().getPrice());
								a1.addDell();
							}
							
						} else if(choose2 == 2) {
							
							System.out.println("\nThat's sad that you don't want to buy this property.\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 2);
					
				} else {
					
					if(a1.checkDell() == 0) {
						
						System.out.println("\nOh no. You are currently at someone's property.\nYou have to pay rent.\nIf you own this property, your money loss will be refunded when it's your turn\n");
						a1.setMoney(a1.getMoney() - board1.toDell().getRent());
						board1.payRent(board1.toDell().getRent());
						
					} else {
						
						System.out.println("\nThis is your property, you get to stay here untill your next move.\n");
					}
				}
				
			} else if(a1.getPosition() == 20) {
				
				System.out.println("You are at Samsung location.");
				
				if(board1.toSamsung().getAvailability() == 1) {
					
					do {
						
						System.out.println("\nDo you want to buy this property?\nPrice: " + board1.toSamsung().getPrice() + "\nRent: " + board1.toSamsung().getRent() + "\n\n1. Yes\n2. No");
						choose2 = input.nextInt();
						
						if(choose2 == 1) {
							
							if(a1.getMoney() < board1.toSamsung().getPrice()) {
								
								System.out.println("\nSorry, you don't have enough money to make a purchase.\n");
								
							} else {
								
								System.out.println("\n\nCongratulations on buying this property, you are now the owner!\n");
								a1.addProperty(board1.toSamsung());
								board1.toSamsung().setAvailability(0);
								a1.addBluePoints();
								a1.setMoney(a1.getMoney() - board1.toSamsung().getPrice());
								a1.addSamsung();
							}
							
						} else if(choose2 == 2) {
							
							System.out.println("\nThat's sad that you don't want to buy this property.\n");
							
						} else {
							
							System.out.println("\nInvalid input, please try again.\n");
						}
						
					}while(choose2 < 1 || choose2 > 2);
					
				} else {
					
					if(a1.checkSamsung() == 0) {
						
						System.out.println("\nOh no. You are currently at someone's property.\nYou have to pay rent.\nIf you own this property, your money loss will be refunded when it's your turn\n");
						a1.setMoney(a1.getMoney() - board1.toSamsung().getRent());
						board1.payRent(board1.toSamsung().getRent());
						
					} else {
						
						System.out.println("\nThis is your property, you get to stay here untill your next move.\n");
					}
				}
			}
		
		}while(a1.getPosition() > 20);
	}

	//Method for sorting properties' prices if player selects this option.
	public static int[] bubbleSort(int[] a) {
		
		int temp = 0;
		
		for(int i = 0; i < a.length; i++) {
			for(int j = i+1; j < a.length; j++) {
				
				if(a[i] > a[j]) {
					
					temp = a[i];
					a[i] = a[j];
					a[j] = temp;
					
										
				}
			}			
		}
		
		return a;
	}
	
	//Method to build houses, if he owns all of the properties of the one color.
	public static void buildHouses(Board board, Player a1, Scanner input) {
		
		String choose;
		int check = 0;
		
		System.out.println("\n\nKeep in mind, you can only purchase one house on ecah property.\nNext time rent would not be increased.\nHowever money would still be taken, so be sure to think before doing something.\n");
		
		//prints whether player can buy houses on these properties.
		if(a1.checkBlueHouse() == true) {
			
			System.out.println("You can purchase houses on blue colored properties");
			check = 1;
		}
		
		//prints whether player can buy houses on these properties.
		if(a1.checkGreenHouse() == true) {
			
			System.out.println("You can purchase houses on green colored properties.");
			check = 1;
		}
		
		//prints whether player can buy houses on these properties.
		if(a1.checkRedHouse() == true) {
			
			System.out.println("You can purchase houses on red colored properties.");
			check = 1;
		}
		
		//prints whether player can buy houses on these properties.
		if(a1.checkWhiteHouse() == true) {
			
			System.out.println("You can purchase houses on white colored properties.");
			check = 1;
		}
		
		//prints whether player can buy houses on these properties.
		if(a1.checkYellowHouse() == true) {
			
			System.out.println("You can purchase houses on yellow colored properties.");
			check = 1;
		}
		
		//if not, player sees the corresponding message.
		if(a1.checkBlueHouse() == false && a1.checkGreenHouse() == false && a1.checkRedHouse() == false && a1.checkWhiteHouse() == false && a1.checkYellowHouse() == false) {
			
			System.out.println("You cannot purchase any properties, sorry");
		}
		
		if(check == 1) {
			
			//do-while loop to avoid wrong inputs.
			do {
				
				System.out.println("Select where do you want to purchase houses, price $1500 (input color): ");
				choose = input.next();
				
				//if-else statement for what color player wants to build his houses on.
				if(choose.toLowerCase().equals("blue")) {
					
					System.out.println("You have purchased houses on all blue properties, the rent has now increased.\nCheck the rent in the main menu");
					board.toApple().setRent(1000);
					board.toSamsung().setRent(1250);
					a1.setMoney(a1.getMoney() - 1500);
					check = 0;
					break;
					
				} else if(choose.toLowerCase().equals("green")) {
					
					System.out.println("You have purchased houses on all green properties, the rent has now increased.\nCheck the rent in the main menu");
					board.toRazer().setRent(600);
					board.toStaples().setRent(400);
					board.toIntel().setRent(300);
					a1.setMoney(a1.getMoney() - 1500);
					check = 0;
					break;
					
				} else if(choose.toLowerCase().equals("red")) {
					
					System.out.println("You have purchased houses on all red properties, the rent has now increased.\nCheck the rent in the main menu");
					board.toManageEngine().setRent(400);
					board.toHP().setRent(270);
					a1.setMoney(a1.getMoney() - 1500);
					check = 0;
					break;
					
				} else if(choose.toLowerCase().equals("white")) {
					
					System.out.println("You have purchased houses on all white properties, the rent has now increased.\nCheck the rent in the main menu");
					board.toIBM().setRent(650);
					board.toAmazon().setRent(450);
					board.toEricsson().setRent(250);
					a1.setMoney(a1.getMoney() - 1500);
					check = 0;
					break;
					
				} else if(choose.toLowerCase().equals("yellow")) {
					
					System.out.println("You have purchased houses on all yellow properties, the rent has now increased.\nCheck the rent in the main menu");
					board.toBelking().setRent(350);
					board.toHoneywell().setRent(500);
					board.toDell().setRent(400);
					a1.setMoney(a1.getMoney() - 1500);
					check = 0;
					break;
					
				} else {
					
					System.out.println("\nInvalid input, please try again.\n");
				}
				
			}while(!choose.toLowerCase().equals("blue") || !choose.toLowerCase().equals("green") || !choose.toLowerCase().equals("red") || !choose.toLowerCase().equals("white") || !choose.toLowerCase().equals("yellow"));
			
		} else {
			
			System.out.println();
		}
	}
	
	//Method for saving data to a file.
	public static void saveData(Player a, Scanner input) {
		
		String path;
		
		//entering the path of the file player wants to save his data to.
		System.out.println("Enter the path of the file you want to save your data to.\nThe file will be created by itself, you don't have to create it\nIf file has been already created, don't worry, the new one shall now appear.\nPlease use \"/\" when writing path");
		path = input.next();
		
		File f = new File(path);
		
		//try-catch statement to save data to a file.
		try {
			
			f.createNewFile();
			
			FileWriter out = new FileWriter(f);
			BufferedWriter write = new BufferedWriter(out);
			
			write.write(Integer.toString(a.getProperties().length));
			write.newLine();
			write.write(a.saveData());
			write.newLine();
			
			write.close();
			out.close();
			
			System.out.println("The data has been saved.\n");
			
		} catch(IOException e) {
			
			System.err.println("IOException: " + e.getMessage());
		}
	}
	
	//Method to load data from the file. Returns player.
	public static Player loadPlayer(String a, Board board) {
		
		int array, money;
		Player p = null;
		File p1 = new File(a);
		
		//try-catch statement to load data from the file.
		try {
			
			FileReader in = new FileReader(p1);
			BufferedReader read = new BufferedReader(in);
			
			String propertiesArray = read.readLine();
			
			array = Integer.parseInt(propertiesArray);
			
			String name = read.readLine();
			String moneyString = read.readLine();
			
			money = Integer.parseInt(moneyString);
			
			p = new Player(name);
			p.setMoney(money);
			
			//for loop to repeat the process for reading the properties, if you have multiple.
			for(int i = 0; i < array; i++) {
				
				String propertyName = read.readLine();
				String propertyPrice = read.readLine();
				String propertyRent = read.readLine();
				String propertyColor = read.readLine();
				String propertyAvailability = read.readLine();
				
				int price = Integer.parseInt(propertyPrice);
				int rent = Integer.parseInt(propertyRent);
				int availability = Integer.parseInt(propertyAvailability);
				
				Property pp = new Property(price, rent, propertyName, propertyColor);
				pp.setAvailability(availability);
				p.addProperty(pp);
				
				//If you owned IBM, property in the Board class will be updated.
				if(pp.getName().equals("IBM")) {
					
					board.setIBM(pp);
					p.addIBM();
					p.addWhitePoints();
				}
				
				//If you owned Razer, property in the Board class will be updated.
				if(pp.getName().equals("Razer")) {
					
					board.setRazer(pp);
					p.addRazer();
					p.addGreenPoints();
				}
				
				//If you owned ManageEngine, property in the Board class will be updated.
				if(pp.getName().equals("ManageEngine")) {
					
					board.setManageEngine(pp);
					p.addManageEngine();
					p.addRedPoints();
				}
				
				//If you owned Amazon, property in the Board class will be updated.
				if(pp.getName().equals("Amazon")) {
					
					board.setAmazon(pp);
					p.addAmazon();
					p.addWhitePoints();
				}
				
				//If you owned Ericsson, property in the Board class will be updated.
				if(pp.getName().equals("Ericsson")) {
					
					board.setEricsson(pp);
					p.addEricsson();
					p.addWhitePoints();
				}
				
				//If you owned Belking, property in the Board class will be updated.
				if(pp.getName().equals("Belking")) {
					
					board.setBelking(pp);
					p.addBelking();
					p.addYellowPoints();
				}
				
				//If you owned Honeywell, property in the Board class will be updated.
				if(pp.getName().equals("Honeywell")) {
					
					board.setHoneywell(pp);
					p.addHoneywell();
					p.addYellowPoints();
				}
				
				//If you owned Apple, property in the Board class will be updated.
				if(pp.getName().equals("Apple")) {
					
					board.setApple(pp);
					p.addApple();
					p.addBluePoints();
				}
				
				//If you owned Samsung, property in the Board class will be updated.
				if(pp.getName().equals("Samsung")) {
					
					board.setSamsung(pp);
					p.addSamsung();
					p.addBluePoints();
				}
				
				//If you owned Dell, property in the Board class will be updated.
				if(pp.getName().equals("Dell")) {
					
					board.setDell(pp);
					p.addDell();
					p.addYellowPoints();
				}
				
				//If you owned HP, property in the Board class will be updated.
				if(pp.getName().equals("HP")) {
					
					board.setHP(pp);
					p.addHP();
					p.addRedPoints();
				}
				
				//If you owned Staples, property in the Board class will be updated.
				if(pp.getName().equals("Staples")) {
					
					board.setStaples(pp);
					p.addStaples();
					p.addGreenPoints();
				}
				
				//If you owned Intel, property in the Board class will be updated.
				if(pp.getName().equals("Intel")) {
					
					board.setIntel(pp);
					p.addIntel();
					p.addGreenPoints();
				}
			}
			
			read.close();
			in.close();
			
		} catch(IOException e) {
			
			System.err.println("IOException: " + e.getMessage());
			
		}
		
		return p;
	}
}
